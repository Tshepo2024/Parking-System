// Hash function for password (simple hash for demo purposes, use stronger encryption in production)
function hashPassword(password) {
    return btoa(password); // Use base64 encoding as a simple hashing example
}

function registerUser(event) {
    event.preventDefault();
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const carNumber = document.getElementById('car-number').value;
    const password = document.getElementById('password').value;
    
    const users = JSON.parse(localStorage.getItem('users')) || [];
    
    // Check if the email is already registered
    const existingUser = users.find(user => user.email === email);
    if (existingUser) {
        document.getElementById('error').textContent = "Email already registered!";
        return;
    }
    
    // Register the user
    const newUser = {
        name,
        email,
        carNumber,
        password: hashPassword(password), // Store hashed password
    };
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    alert("Registration successful! Please login.");
    window.location.href = 'index.html'; // Redirect to login page
}

function loginUser(event) {
    event.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    const users = JSON.parse(localStorage.getItem('users')) || [];
    
    const user = users.find(user => user.email === email && user.password === hashPassword(password));
    
    if (user) {
        localStorage.setItem('loggedInUser', JSON.stringify(user));
        window.location.href = 'dashboard.html'; // Redirect to dashboard
    } else {
        document.getElementById('error').textContent = "Invalid email or password!";
    }
}

function loadDashboardPage() {
    const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
    if (!loggedInUser) {
        window.location.href = 'index.html'; // Redirect if not logged in
        return;
    }
    
    document.getElementById('userName').textContent = loggedInUser.name;
    document.getElementById('carNumber').textContent = loggedInUser.carNumber;
    
    if (loggedInUser.startTime) {
        const startTime = new Date(loggedInUser.startTime);
        const currentTime = new Date();
        const duration = ((currentTime - startTime) / (1000 * 60 * 60)).toFixed(2); // Duration in hours
        const totalAmount = (duration * 10).toFixed(2); // Assuming $10/hour rate
        
        document.getElementById('startTime').textContent = startTime.toLocaleString();
        document.getElementById('duration').textContent = `${duration} hours`;
        document.getElementById('totalAmount').textContent = `$${totalAmount}`;
        document.getElementById('referenceNumber').textContent = loggedInUser.referenceNumber;
    }
}

function checkIn() {
    const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
    if (loggedInUser) {
        if (!loggedInUser.startTime) {
            const startTime = new Date();
            const referenceNumber = generateReferenceNumber();
            loggedInUser.startTime = startTime;
            loggedInUser.referenceNumber = referenceNumber;
            localStorage.setItem('loggedInUser', JSON.stringify(loggedInUser));

            // Show the check-in modal with details
            showCheckinModal(startTime, referenceNumber);
        } else {
            // If the user has already checked in, redirect to checkout
            window.location.href = 'checkout.html';
        }
    } else {
        alert('You must be logged in to check in.');
    }
}

function showCheckinModal(startTime, referenceNumber) {
    const modalMessage = `Check-in successful at ${startTime.toLocaleString()}<br>Reference Number: ${referenceNumber}`;
    document.getElementById('modalMessage').innerHTML = modalMessage; // Display the message in the modal
    document.getElementById('checkinModal').style.display = 'block'; // Show the modal
}

function closeModal() {
    document.getElementById('checkinModal').style.display = 'none'; // Hide the modal
}

function proceedToCheckout() {
    window.location.href = 'checkout.html'; // Redirect to checkout page
}

function generateReferenceNumber() {
    return Math.floor(100000 + Math.random() * 900000).toString(); // Generate a random reference number
}


function checkIn() {
    const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
    if (loggedInUser && !loggedInUser.startTime) {
        const startTime = new Date();
        const referenceNumber = generateReferenceNumber();
        loggedInUser.startTime = startTime;
        loggedInUser.referenceNumber = referenceNumber;
        localStorage.setItem('loggedInUser', JSON.stringify(loggedInUser));
        
        // Redirect to checkout.html after check-in
        window.location.href = 'checkout.html';
    } else if (loggedInUser.startTime) {
        // If already checked in, just go to checkout.html
        window.location.href = 'checkout.html';
    }
}
function checkOut() {
    const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
    if (loggedInUser && loggedInUser.startTime) {
        const startTime = new Date(loggedInUser.startTime);
        const currentTime = new Date();
        const duration = ((currentTime - startTime) / (1000 * 10 * 10)).toFixed(2); // Duration in hours
        const totalAmount = (duration * 10).toFixed(2); // Assuming $10/hour rate

        // Save the payment details in localStorage to access them on the payment page
        const paymentDetails = {
            duration,
            totalAmount,
            referenceNumber: loggedInUser.referenceNumber,
            startTime: startTime.toLocaleString(),
            endTime: currentTime.toLocaleString(),
        };
        localStorage.setItem('paymentDetails', JSON.stringify(paymentDetails));

        // Redirect to the payment page
        window.location.href = 'payment.html';
    } else {
        alert('You have not checked in yet!');
    }
}


function logout() {
    localStorage.removeItem('loggedInUser');
    window.location.href = 'index.html'; // Redirect to login
}
function loginUser(event) {
    event.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    const users = JSON.parse(localStorage.getItem('users')) || [];
    
    const user = users.find(user => user.email === email && user.password === hashPassword(password));
    
    if (user) {
        localStorage.setItem('loggedInUser', JSON.stringify(user));
        
        // Check if the user had already checked in and didn't check out
        if (user.startTime) {
            window.location.href = 'checkout.html'; // Redirect to checkout if they haven't checked out
        } else {
            window.location.href = 'dashboard.html'; // Redirect to dashboard if no active check-in
        }
    } else {
        document.getElementById('error').textContent = "Invalid email or password!";
    }
}
function loadDashboardPage() {
    const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));

    if (!loggedInUser) {
        window.location.href = 'index.html'; // Redirect if not logged in
        return;
    }

    document.getElementById('userName').textContent = loggedInUser.name;
    document.getElementById('carNumber').textContent = loggedInUser.carNumber;

    if (loggedInUser.startTime) {
        const startTime = new Date(loggedInUser.startTime);
        const currentTime = new Date();
        const duration = ((currentTime - startTime) / (1000 * 60 * 60)).toFixed(2); // Duration in hours
        const totalAmount = (duration * 150).toFixed(2); // Assuming R150/hour rate

        document.getElementById('startTime').textContent = startTime.toLocaleString();
        document.getElementById('duration').textContent = `${duration} hours`;
        document.getElementById('totalAmount').textContent = `R${totalAmount}`;
        document.getElementById('referenceNumber').textContent = loggedInUser.referenceNumber;
    }
}

function checkOut() {
    const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));

    if (loggedInUser && loggedInUser.startTime) {
        const startTime = new Date(loggedInUser.startTime);
        const currentTime = new Date();
        const duration = ((currentTime - startTime) / (1000 * 10 * 10)).toFixed(2); // Duration in hours
        const ratePerHour = 150; // Assuming R150/hour rate (R75 per 30 minutes)
        const totalAmount = (duration * ratePerHour).toFixed(2); // Calculating total in rands

        // Save the payment details in localStorage to access them on the payment page
        const paymentDetails = {
            duration,
            totalAmount,
            referenceNumber: loggedInUser.referenceNumber,
            startTime: startTime.toLocaleString(),
            endTime: currentTime.toLocaleString(),
        };
        localStorage.setItem('paymentDetails', JSON.stringify(paymentDetails));

        // Redirect to the payment page
        window.location.href = 'payment.html';
    } else {
        alert('You have not checked in yet!');
    }
}

function loginUser(event) {
    event.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    const users = JSON.parse(localStorage.getItem('users')) || [];
    
    const user = users.find(user => user.email === email && user.password === hashPassword(password));
    
    if (user) {
        // Check if the user has an incomplete checkout session
        if (user.startTime && !user.checkedOut) {
            alert("You need to complete your checkout first.");
            localStorage.setItem('loggedInUser', JSON.stringify(user)); // Save the session
            window.location.href = 'checkout.html'; // Redirect to checkout
            return;
        }

        // Save the logged in user session
        localStorage.setItem('loggedInUser', JSON.stringify(user));
        window.location.href = 'dashboard.html'; // Redirect to dashboard
    } else {
        document.getElementById('error').textContent = "Invalid email or password!";
    }
}

function checkIn() {
    const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
    
    if (loggedInUser) {
        // Check if the user has an active session that hasn't been checked out
        if (loggedInUser.startTime && !loggedInUser.checkedOut) {
            alert("You still have an active session. You need to checkout first.");
            window.location.href = 'checkout.html'; // Redirect to checkout
            return;
        }

        const startTime = new Date();
        const referenceNumber = generateReferenceNumber(); // Generate a unique reference number
        const ticketNumber = generateTicketNumber(); // Generate a random ticket number

        loggedInUser.startTime = startTime;
        loggedInUser.referenceNumber = referenceNumber;
        loggedInUser.ticketNumber = ticketNumber; // Store the ticket number
        loggedInUser.checkedOut = false; // Mark that the user hasn't checked out yet

        localStorage.setItem('loggedInUser', JSON.stringify(loggedInUser));
        alert("Check-in successful at " + startTime.toLocaleString() + ". Ticket Number: " + ticketNumber + ". Reference Number: " + referenceNumber);
        window.location.href = 'checkout.html';
    }
}


// Helper function to generate a random alphanumeric ticket number
function generateTicketNumber() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let ticketNumber = '';
    for (let i = 0; i < 8; i++) {
        ticketNumber += chars[Math.floor(Math.random() * chars.length)];
    }
    return ticketNumber;
}
function logoutWithoutCheckout() {
    const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
    if (loggedInUser && loggedInUser.startTime && !loggedInUser.checkedOut) {
        alert('You will need to check out when you log back in.');
    }
    localStorage.removeItem('loggedInUser');
    window.location.href = 'index.html'; // Log out and redirect to login
}
function checkoutUser() {
    const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));

    if (loggedInUser && loggedInUser.startTime) {
        const startTime = new Date(loggedInUser.startTime);
        const currentTime = new Date();

        // Calculate the duration and total amount here
        const durationInMilliseconds = currentTime - startTime;
        const durationInMinutes = Math.floor(durationInMilliseconds / (1000 * 60));
        const durationIn30MinIntervals = Math.ceil(durationInMinutes / 30);
        const ratePer30Minutes = 75; // Assuming a rate of R75 per 30 minutes
        const totalAmount = (durationIn30MinIntervals * ratePer30Minutes).toFixed(2);

        alert(`Checked out! Total duration: ${durationIn30MinIntervals * 30} minutes. Total amount: R${totalAmount}`);

        // Mark the user as checked out
        loggedInUser.checkedOut = true;
        localStorage.setItem('loggedInUser', JSON.stringify(loggedInUser));

        window.location.href = 'payment.html'; // Redirect to payment page
    }
}

